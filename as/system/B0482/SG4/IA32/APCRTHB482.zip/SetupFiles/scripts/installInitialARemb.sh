#!/bin/bash

###############################################
# Installs Hypervisor on the given partition
#  $1 ... device
#  $2 ... partition number
###############################################
function installInitialARemb(){

	local arembDev=$1
	local arembPartNr=$2

	logWriteDebugFunction "installInitialARemb($arembDev, $arembPartNr)"

	checkLastParam $arembPartNr "no partition number given."

	local rpshdPartNr=
	local rpshdsPartNr=
	local arembSysPart=
	local arembRpshdPart=
	local arembRpshdsPart=
	mountPartition arembSysPart $arembDev$arembPartNr
	local arembInstDir=$BASEAR_DIR
	local priModulesDir=
	local secModulesDir=
	local partCnt=
	
	# copy inital AR files to system partition
	logWriteDebugFunctionCall "cp -f -r $arembInstDir/* $arembSysPart"
	logWriteDebugFunctionCall "touch $arembSysPart/$RTH_TRACE_FILE"

if  [ "$uefiInstall" = "1" ]; then
	partCnt=${#MIN_PART_SIZES[@]}
else
	partCnt=1
fi

	if (( partCnt < 3 )); then		# einfaches B&R Modulsystem
		rpshdPartNr=$arembPartNr
		rpshdsPartNr=$arembPartNr
	else											# sicheres B&R Modulsystem
		let rpshdPartNr=$arembPartNr+1
		let rpshdsPartNr=$arembPartNr+2
	fi
	
	# mount RPSHD and RPSHDS
	mountPartition arembRpshdPart $arembDev$rpshdPartNr
	mountPartition arembRpshdsPart $arembDev$rpshdsPartNr	
	priModulesDir=$arembRpshdPart/RPSHD/SYSROM	
	secModulesDir=$arembRpshdsPart/RPSHDS/SYSROM

	# copy inital AR files and project modules to RPSHD (and RPSHDS)
	logWriteDebugFunctionCall "mkdir -p $priModulesDir"
	logWriteDebugFunctionCall "mkdir -p $secModulesDir"
	logWriteDebugFunctionCall "mv -f $arembSysPart/*.br $priModulesDir"
	logWriteDebugFunctionCall "cp -f $priModulesDir/*.br $secModulesDir"

if  [ "$uefiInstall" = "1" ]; then
	_installTransferModule $arembRpshdPart
fi

	umountDir $arembRpshdsPart
	umountDir $arembRpshdPart
	umountDir $arembSysPart

	logWriteInfo "ARemb installed"
}

###############################################
# Installs Transfermodul to the given directory
#  $1 ... device
#  $2 ... partition number
###############################################
function _installTransferModule()
{
	local rpsHdPartDir=$1

	logWriteDebugFunction "_installTransferModule($rpsHdPartDir)"

	checkLastParam $rpsHdPartDir "no rpshd dir given."

	local priModulesTransferDir=$rpsHdPartDir/TRANSFER

    getTransferModuleName transferModuleName

	# copy Transfermodul into /TRANSFER/artransfer.br
	logWriteDebugFunctionCall "mkdir -p $priModulesTransferDir"
	logWriteDebugFunctionCall "cp -f $transferModuleName $priModulesTransferDir/artransfer.br"
	
	logWriteInfo "artransfer.br copied"
}