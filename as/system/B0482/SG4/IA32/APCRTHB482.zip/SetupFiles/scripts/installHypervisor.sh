#!/bin/bash

RTH_CFG="ARemb.txt"

###############################################
# Installs Hypervisor on the given partition
#  $1 ... device
#  $2 ... partition number
###############################################
function installHypervisorFiles() {
	local hypDev=$1
	local hypPartNr=$2

	logWriteDebugFunction "installHypervisorFiles($hypDev, $hypPartNr)"

	checkLastParam $hypPartNr "no partition number given."

	local arembSysPart=
	mountPartition arembSysPart $hypDev$hypPartNr

	local arembRthDir=$arembSysPart$RTH_DIR
	local RtsInstDir=$BASEAR_DIR"/System/RTH"
	
		# copy RTS file
	RTS_FILES=("rthx86" "license.txt")
	logWriteDebugFunctionCall "mkdir -p $arembRthDir"
	for i in ${RTS_FILES[@]}
	do
		logWriteDebugFunctionCall "cp -f $RtsInstDir/$i $arembRthDir/"
	done
	logWriteDebugFunctionCall "touch $BASEAR_DIR/$RTH_TRACE_FILE"

	umountDir $arembSysPart

	logWriteInfo "B&R hypervisor installed"
}

function installHypervisorCfg() {
	local gposDev=$1			# device assigned to GPOS per default
	local arDev=$2				# device of AR
	local arPartNr=$3			# partition number of AR system directory
	local extPartNr=$4			# partition number of the extended partition
	local gpos=$5
	local bootline="$6"

	logWriteDebugFunction "installHypervisorCfg($gposDev, $arDev, $arPartNr, $extPartNr, $gpos, $bootline)"

	checkLastParam $bootline "no bootline given."

	mountPartition arembSysPart $arDev$arPartNr

	local arembRthDir=$arembSysPart$RTH_DIR
	local out=$arembRthDir/$RTH_CFG

	createRthCfgHeader $out
	getPciDriveParameters pciBus pciDevice pciFunction
	let extPartNr=$extPartNr-1
	addRthCfgDriveEntry $gposDev $arDev $extPartNr $out $pciBus $pciDevice $pciFunction
	addRthCfgIoRanges $out
	addRthCfgIRQ $out
	_addRthCfgLegacyImagesAndBootline $gpos $bootline $out
	addRthCfgOsEntries $gpos $out
	_addRthCfgPci $out $pciBus $pciDevice $pciFunction
	addRthCfgShmEntries $out
	addRthCfgSystemEntries $out
	addRthCfgTimeSyncEntries $out

	logWriteFile $out

	umountDir $arembSysPart
}

function createRthCfgHeader()
{
	local rthCfgFile=$1

	logWriteDebugFunction "createRthCfgHeader($rthCfgFile)"

	checkLastParam $rthCfgFile "no RTH config file given."

	logWriteDebug "creating RTH config file header: createRthCfgHeader($rthCfgFile)"

	echo "# RTH CONFIG"                                                  > $rthCfgFile
	echo ""                                                              >> $rthCfgFile
}

function addRthCfgIoRanges()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgIoRanges($rthCfgFile)"

	checkLastParam $rthCfgFile "no RTH config file given."

	logWriteDebug "adding entries for IO ranges: addRthCfgIoRanges($rthCfgFile)"

	echo "[/IO_RANGE/0]"                                                 >> $rthCfgFile    #IO range for MTCX
    echo "    \"base_port\"              = uint32: 0x4000"               >> $rthCfgFile
    echo "    \"length\"                 = uint32: 0x0200"               >> $rthCfgFile
    echo "    \"shared\"                 = uint32: 1"                    >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
    echo "# IO range for NMI"                                            >> $rthCfgFile
    echo "[/IO_RANGE/1]"                                                 >> $rthCfgFile
    echo "    \"OS\"                     = uint32: 1"                    >> $rthCfgFile
    echo "    \"base_port\"              = uint32: 0x61"                 >> $rthCfgFile
    echo "    \"length\"                 = uint32: 0x0001"               >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
    echo "# share IO range for POST codes"                               >> $rthCfgFile
    echo "[/IO_RANGE/2]"                                                 >> $rthCfgFile
    echo "    \"base_port\"              = uint32: 0x80"                 >> $rthCfgFile
    echo "    \"length\"                 = uint32: 0x0001"               >> $rthCfgFile
    echo "    \"shared\"                 = uint32: 1"                    >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
    echo "# IO range for I82371AB_DELAY() in vxbPiixStorage driver"      >> $rthCfgFile
    echo "[/IO_RANGE/3]"                                                 >> $rthCfgFile
    echo "    \"OS\"                     = uint32: 1"                    >> $rthCfgFile
    echo "    \"base_port\"              = uint32: 0x84"                 >> $rthCfgFile
    echo "    \"length\"                 = uint32: 0x0001"               >> $rthCfgFile
}

function addRthCfgIRQ()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgIRQ($rthCfgFile)"

	checkLastParam $rthCfgFile "no RTH config file given."

	logWriteDebug "adding entry for IRQ: addRthCfgIRQ($rthCfgFile)"

    echo "[/IRQ]"                                                        >> $rthCfgFile    #interrupts
    echo "    \"USB_SMI_disable\"        = uint32: 1"                    >> $rthCfgFile    #USB SMI wegen USB legacy abdrehen
    echo "    \"default\"                = uint32: 1"                    >> $rthCfgFile    #default is AR
    echo ""                                                              >> $rthCfgFile
}

function _addRthCfgLegacyImagesAndBootline()
{
	local gposTag=$1
	local linuxBootLine=$2
	local rthCfgFile=$3

	logWriteDebugFunction "_addRthCfgLegacyImagesAndBootline($gposTag, $linuxBootLine, $rthCfgFile)"

	checkLastParam $rthCfgFile "no RTH config file given."

	echo "[/OS/0/RUNTIME/0]"                                              >> $rthCfgFile
	if [ "$gposTag" = "$WINDOWS_TAG" ]; then
		echo "    \"image_0\"                = \"(DRIVE0,0)\""            >> $rthCfgFile
	else
	    echo "    \"bootline\"               = \"$linuxBootLine\""        >> $rthCfgFile
	    echo "    \"image_0\"                = \"$LINUX_VMLINUZ_NAME\""   >> $rthCfgFile
	    echo "    \"image_1\"                = \"$LINUX_INITRAMFS_NAME\"" >> $rthCfgFile
	fi
    echo ""                                                               >> $rthCfgFile	
}

function addRthCfgOsEntries()
{
	local gposName=$1
	local rthCfgFile=$2
	local dramSizeInB=

	logWriteDebugFunction "addRthCfgOsEntries($gposName, $rthCfgFile)"

	let dramSizeInB=512*1024*1024			#512MB default DRAM

	checkLastParam $rthCfgFile "no RTH config file given."

	logWriteDebug "adding OS entries: addRthCfgOsEntries($gposName, $rthCfgFile)"

	echo "[/OS/0]"                                                       >> $rthCfgFile
	echo "    \"boot_priority\"          = uint32: 0"                    >> $rthCfgFile
	echo "    \"name\"                   = \"$gposName\""                >> $rthCfgFile
	echo "    \"trace_partition_number\" = uint32: 0"                    >> $rthCfgFile
	echo "    \"virtualized\"            = uint32: 1"                    >> $rthCfgFile
	echo ""                                                              >> $rthCfgFile
    echo "[/OS/1/RUNTIME/0]"                                             >> $rthCfgFile
    echo "    \"bootline\"               = \"vnet(0,0) e=192.168.2.2\""  >> $rthCfgFile
    echo "    \"image_0\"                = \"arimg\""                    >> $rthCfgFile
    echo "    \"max_image_size_0\"       = uint32: 0x2000000"            >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
    echo "[/OS/1]"                                                       >> $rthCfgFile
    echo "    \"SMT\"                    = uint32: 0"                    >> $rthCfgFile
    echo "    \"boot_priority\"          = uint32: 1"                    >> $rthCfgFile
    echo "    \"cores\"                  = bytelist: 1"                  >> $rthCfgFile
    echo "    \"memory_size\"            = uint64: $dramSizeInB"         >> $rthCfgFile
    echo "    \"name\"                   = \"ARemb\""                    >> $rthCfgFile
    echo "    \"restricted_IO\"          = uint32: 1"                    >> $rthCfgFile
    echo "    \"virtual_MMU\"            = uint32: 1"                    >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
}

function getPciDriveParameters()
{
	local __pcibus=$1
	local __pcidevice=$2
	local __pcifunction=$3

	logWriteDebugFunction "getPciDriveParameters($__pcibus, $__pcidevice, $__pcifunction)"

	checkLastParam $__pcifunction "no pcifunction variable given."

	local pcibus=$(lspci | grep "Class 0106" | cut -d ':' -f 1)
	local pcidevice=$(lspci | grep "Class 0106" | cut -d ':' -f 2 | cut -d '.' -f 1 )
	local pcifunction=$(lspci | grep "Class 0106" | cut -d ':' -f 2 | cut -d '.' -f 2 | cut -d ' ' -f 1 )
	
	logWriteDebug "drive parameters: ($pcibus:$pcidevice:$pcifunction)"
	
	eval "${__pcibus}='${pcibus}'"
	eval "${__pcidevice}='${pcidevice}'"
	eval "${__pcifunction}='${pcifunction}'"
}

function addRthCfgDriveEntry()
{
	local gposDev=$1
	local arDev=$2
	local arRthPartNr=$3
	local rthCfgFile=$4
	local pcibus=$5
	local pcidevice=$6
	local pcifunction=$7
	local arPciport=
	local gposPciport=

	logWriteDebugFunction "addRthCfgDriveEntry($gposDev, $arDev, $arRthPartNr, $rthCfgFile, $pcibus, $pcidevice, $pcifunction)"

	checkLastParam $pcifunction "no pci function given."

	arPciport=$(lsscsi | grep "$arDev" | cut -d '[' -f 2 | cut -d ':' -f 1 )
	gposPciport=$(lsscsi | grep "$gposDev" | cut -d '[' -f 2 | cut -d ':' -f 1 )

	# gpos ist immer auf DRIVE0 installiert
	local driveIndex=0
	if [ "$arPciport" != "$gposPciport" ]; then
		_writeRthCfgDriveEntry $pcibus $pcidevice $pcifunction $gposPciport $driveIndex $rthCfgFile
		let driveIndex=$driveIndex+1
	fi

	_writeRthCfgDrivePartitionEntry $driveIndex $arRthPartNr $rthCfgFile
	_writeRthCfgDriveEntry $pcibus $pcidevice $pcifunction $arPciport $driveIndex $rthCfgFile
	let driveIndex=$driveIndex+1

	# restliche ports dieses SATA controllers dem GPOS zuweisen
	local OIFS=$IFS
	IFS=$'\n'
	local allPorts=$(lsscsi -H | grep ahci | cut -d '[' -f 2 | cut -d ']' -f 1)
	local arr=$allPorts
	local port=
	for port in $arr
	do
		if [ "$port" != "$arPciport" ] && [ "$port" != "$gposPciport" ] ; then
			_writeRthCfgDriveEntry $pcibus $pcidevice $pcifunction $port $driveIndex $rthCfgFile
			let driveIndex=$driveIndex+1
		fi
	done
	IFS=$OIFS
}

function _writeRthCfgDriveEntry()
{
	local pcibus=$1
	local pcidevice=$2
	local pcifunction=$3
	local pciport=$4
	local driveNr=$5
	local rthCfg=$6

	logWriteDebugFunction "_writeRthCfgDriveEntry($pcibus, $pcidevice, $pcifunction, $pciport, $driveNr, $rthCfg)"

	checkLastParam $rthCfg "no RTH config file given."

    echo "[/DRIVE/$driveNr]"                                             >> $rthCfg
    echo "    \"bus\"                    = uint32: 0x$pcibus"            >> $rthCfg
    echo "    \"default\"                = uint32: 0"                    >> $rthCfg
    echo "    \"device\"                 = uint32: 0x$pcidevice"         >> $rthCfg
    echo "    \"function\"               = uint32: 0x$pcifunction"       >> $rthCfg
    echo "    \"port\"                   = uint32: 0x$pciport"           >> $rthCfg
    echo ""                                                              >> $rthCfg
}

function _writeRthCfgDrivePartitionEntry()
{
	local driveNr=$1
	local arPartNr=$2
	local rthCfg=$3
	local i=
	local partCnt=

	logWriteDebugFunction "_writeRthCfgDrivePartitionEntry($driveNr, $arPartNr, $rthCfg)"

	checkLastParam $rthCfg "no RTH config file given."

if  [ "$uefiInstall" = "1" ]; then
	partCnt=${#MIN_PART_SIZES[@]}
else
	partCnt=1
fi

	for (( i=0; i<partCnt; i++ ))
	do
		echo "[/DRIVE/$driveNr/PARTITION/$arPartNr]"                         >> $rthCfg
		echo "    \"OS\"                     = uint32: 1"                    >> $rthCfg
		echo ""                                                              >> $rthCfg
		let arPartNr=$arPartNr+1
	done
}

function _addRthCfgPci()
{
	local rthCfgFile=$1
	local pcibus=$2
	local pcidevice=$3
	local pcifunction=$4

	logWriteDebugFunction "_addRthCfgPci($rthCfgFile, $pcibus, $pcidevice, $pcifunction)"

	checkLastParam $pcifunction "no pci function given."

    echo "[/PCI/0]"                                                      >> $rthCfgFile
    echo "    \"OS\"                     = uint32: 1"                    >> $rthCfgFile	#all B&R devices => AR
    echo "    \"vendor_ID\"              = uint32: 0x1677"               >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
    echo "[/PCI/1]"                                                      >> $rthCfgFile	#SATA controller => GPOS
    echo "    \"OS\"                     = uint32: 0"                    >> $rthCfgFile
    echo "    \"bus\"                    = uint32: 0x$pcibus"            >> $rthCfgFile
    echo "    \"device\"                 = uint32: 0x$pcidevice"         >> $rthCfgFile
    echo "    \"function\"               = bytelist: $pcifunction"       >> $rthCfgFile
    echo "    \"interrupt_mode\"         = uint32: 2"                    >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
    echo "[/PCI]"                                                        >> $rthCfgFile
    echo "    \"default\"                = uint32: 1"                    >> $rthCfgFile    #default is AR
    echo ""                                                              >> $rthCfgFile
}

function addRthCfgShmEntries()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgShmEntries($rthCfgFile)"

	checkLastParam $rthCfgFile "no rth cfg file given."
	
    echo "[/SHM/0]"                                                      >> $rthCfgFile    #shared memory
    echo "    \"name\"                   = \"trace\""                    >> $rthCfgFile
    echo "    \"size\"                   = uint64: 0x4000"               >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
}

function addRthCfgSystemEntries()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgSystemEntries($rthCfgFile)"

	checkLastParam $rthCfgFile "no rth cfg file given."
	
    echo "[/SYSTEM]"                                                     >> $rthCfgFile
    echo "    \"IOMMU\"                  = uint32: 1"                    >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile
}

function addRthCfgTimeSyncEntries()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgTimeSyncEntries($rthCfgFile)"

	checkLastParam $rthCfgFile "no rth cfg file given."

    echo "[/TIME_SYNC]"                                                  >> $rthCfgFile
    echo "    \"auto_start\"             = uint32: 1"                    >> $rthCfgFile
    echo "    \"master\"                 = uint32: 0"                    >> $rthCfgFile
    echo "    \"sync_interval\"          = uint32: 1000"                 >> $rthCfgFile
    echo ""                                                              >> $rthCfgFile	
}
