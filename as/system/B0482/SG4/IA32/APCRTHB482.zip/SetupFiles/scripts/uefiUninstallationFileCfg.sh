#!/bin/bash
# uefiUninstallationFileCfg.sh - perform the UEFI B&R hypervisor uninstallation.

UNINSTALL_CFG_FILE="uninstall.cfg"


function doUefiUninstallationFileCfg()
{
    local uninstFileDir=
    
    showUninstProgress "0"
    logWriteUninstallStart

    # detect ESP partition
    getEspPartition espDevice espPartNr
    showUninstProgress "20"

    mountPartition uninstFileDir $espDevice$espPartNr
	dos2unix ${uninstFileDir}/$UNINSTALL_CFG_FILE
	showUninstProgress "30"
    
    #uninstall file aufrufen
    bash "${SHELL_SCRIPT_DIR}/uefiUninstallationCallFileCfg.sh" "$SETUP_DIR" "$SHELL_SCRIPT_DIR" "${uninstFileDir}/$UNINSTALL_CFG_FILE"
    showUninstProgress "70"
    
    #uninstall file loeschen
    logWriteDebugFunctionCall "rm -f ${uninstFileDir}/$UNINSTALL_CFG_FILE"
    showUninstProgress "90"
    
    umountDir $uninstFileDir

    showUninstProgress "100"
    logWriteUninstallFinished

    setPageIdx $UNINST_FINISHED_IDX
}

function hasUninstallCfgFile()
{
    local __newUefiCfg=$1
    
    logWriteDebugFunction "hasUninstallCfgFile($__newUefiCfg)"

	checkLastParam ${__newUefiCfg} "no new uefi cfg given."
	
    local newUefiInst="0"

    getEspPartition espDevice espPartNr
    mountPartition newDir $espDevice$espPartNr 
    if [ -e $newDir/$UNINSTALL_CFG_FILE ]; then
        newUefiInst="1"
    fi
    umountDir $newDir
    
    eval "${__newUefiCfg}='${newUefiInst}'"				
}

function logWriteInitUninstallFile() 
{
	logWriteDebugFunction "logWriteInitUninstallFile($@)"
	
    getEspPartition espDev espPart
    
    logWriteDebug "ESP:" $espDev $espPart
    
    mountPartition newDir $espDev$espPart
    
    touch "$newDir/$UNINSTALL_CFG_FILE"
    logWriteDebug "emptying uninstallation file $newDir/$UNINSTALL_CFG_FILE"  
    
    umountDir $newDir
}

function logWriteAddUninstallCmd() 
{
	logWriteDebugFunction "logWriteAddUninstallCmd($@)"
	
    getEspPartition espDev espPart
    
    logWriteDebug "ESP:" $espDev $espPart
    
    mountPartition newDir $espDev$espPart
    
    echo "$@" >> "$newDir/$UNINSTALL_CFG_FILE"
    logWriteDebug "adding entry for uninstallation \"echo $@\" into $newDir/$UNINSTALL_CFG_FILE"  
    
    umountDir $newDir
}