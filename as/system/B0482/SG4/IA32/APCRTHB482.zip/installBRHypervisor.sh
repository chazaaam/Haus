#!/bin/bash

#root rechte anfordern
if [ "$(id -u)" != "0" ]; then
  exec sudo bash $0 $*
fi

function pause(){
	local message="$@"
	[ -z $message ] && message="Press [Enter] key to continue, [ESC] to exit..."
	read -p "$message" readEnterKey
	if [ "$readEnterKey" = $'\e' ]; then		# ESC
		exit 0;
	fi
}

CHROOT_DIR=~/tmp/tmpBRHypervisor
USB_STICK_DIR="`dirname $0`"                          #root-directory of the installation files (corresponds to mounted USB Root Dir)
SETUP_DIR="/Setup" 
CURRENT_DIR="`pwd`"

readtraceOutput=$(readtrace 2> /dev/null)
if [ -z "$readtraceOutput" ] ; then
	echo "Error: You have to install the B&R Hypervisor driver for Linux first."
	exit
else
	readtraceOutput=${readtraceOutput:0:20}		#just the first few characters
	if [ "$readtraceOutput" = "Real-Time Hypervisor" ]; then
	    echo "Error: You cannot uninstall B&R Hypervisor while it is running. You have to reboot the system and start Linux alone."
		exit
	fi
fi

if [ -d "$CHROOT_DIR" ]; then
  rm -r $CHROOT_DIR
fi
mkdir -p $CHROOT_DIR$SETUP_DIR 

# ermitteln der echten devices
usbStickRealDevice=$(realpath $(df $USB_STICK_DIR | grep '^/' | cut -d' ' -f1))
chrootRealDevice=$(realpath $(df $CHROOT_DIR | grep '^/' | cut -d' ' -f1))

# wenn $USB_STICK_DIR und $CHROOT_DIR auf gleichen devices liegen muss folgender workaround durchgef�hrt werden
if [ "$usbStickRealDevice" = "$chrootRealDevice" ]; then
  cp -f -r /boot $USB_STICK_DIR/boot		# kopieren der grub.cfg dieses devices, weil das sonst mit mount unter chroot nicht ausgelesen werden kann  
  rm -f -r $USB_STICK_DIR/grub				#l�schen des umsonst kopierten grub verzeichnisses des USB Sticks 
fi

cp $USB_STICK_DIR/rootfs.cpio.gz $CHROOT_DIR
gzip -d $CHROOT_DIR/rootfs.cpio.gz
{ cd $CHROOT_DIR; cpio -id --quiet < $CHROOT_DIR/rootfs.cpio ; cd $CURRENT_DIR ; }

mount -t sysfs /sys           $CHROOT_DIR/sys
mount -t proc /proc           $CHROOT_DIR/proc
mount --bind /dev             $CHROOT_DIR/dev
mount --bind /dev/pts         $CHROOT_DIR/dev/pts
mount --bind $USB_STICK_DIR   $CHROOT_DIR$SETUP_DIR

# zus�tzlich "/" und "/boot/efi" in ein Verzeichnis unter $CHROOT_DIR mounten, 
# sonst funktioniert das bootinfoscript nicht richtig
BIND_DIR=$CHROOT_DIR/bind_dir
BIND_ROOT_DIR=$BIND_DIR/root_dir
BIND_BOOT_EFI_DIR=$BIND_DIR/boot_efi_dir
mkdir -p $BIND_ROOT_DIR
mkdir -p $BIND_BOOT_EFI_DIR
mount --bind / $BIND_ROOT_DIR
mount --bind /boot/efi $BIND_BOOT_EFI_DIR

# Aufruf des USB Install Scripts
chroot $CHROOT_DIR bash ARsetup.sh $SETUP_DIR

umount $BIND_BOOT_EFI_DIR
umount -l $BIND_ROOT_DIR

umount $CHROOT_DIR$SETUP_DIR
umount $CHROOT_DIR/dev/pts
umount $CHROOT_DIR/dev
umount $CHROOT_DIR/proc
umount $CHROOT_DIR/sys
